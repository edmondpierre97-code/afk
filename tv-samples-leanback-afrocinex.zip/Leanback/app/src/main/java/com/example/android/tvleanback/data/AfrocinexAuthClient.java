/*
 * Afrocinex — Appelle POST /auth/login sur l'API Afrocinex avec l'identifiant et
 * le mot de passe saisis par l'utilisateur, et renvoie soit le mot de passe
 * d'application émis par WordPress (à conserver pour les appels protégés), soit
 * un message d'erreur lisible.
 */
package com.example.android.tvleanback.data;

import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import javax.net.ssl.HttpsURLConnection;

public class AfrocinexAuthClient extends AsyncTask<Void, Void, AfrocinexAuthClient.Result> {

    private static final String TAG = "AfrocinexAuthClient";

    public static class Result {
        public final boolean success;
        public final String username;
        public final String displayName;
        public final String appPassword;
        public final String errorMessage;

        private Result(boolean success, String username, String displayName, String appPassword,
                String errorMessage) {
            this.success = success;
            this.username = username;
            this.displayName = displayName;
            this.appPassword = appPassword;
            this.errorMessage = errorMessage;
        }

        static Result success(String username, String displayName, String appPassword) {
            return new Result(true, username, displayName, appPassword, "");
        }

        static Result failure(String errorMessage) {
            return new Result(false, "", "", "", errorMessage);
        }
    }

    public interface Callback {
        void onLoginResult(Result result);
    }

    private final String mBaseApiUrl;
    private final String mUsername;
    private final String mPassword;
    private final Callback mCallback;

    public AfrocinexAuthClient(String baseApiUrl, String username, String password,
            Callback callback) {
        mBaseApiUrl = baseApiUrl;
        mUsername = username;
        mPassword = password;
        mCallback = callback;
    }

    @Override
    protected Result doInBackground(Void... voids) {
        try {
            URL url = new URL(mBaseApiUrl + "/auth/login");
            HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");

            JSONObject body = new JSONObject();
            body.put("username", mUsername);
            body.put("password", mPassword);

            try (OutputStream os = connection.getOutputStream()) {
                os.write(body.toString().getBytes(StandardCharsets.UTF_8));
            }

            int status = connection.getResponseCode();
            String responseBody = readStream(status >= 200 && status < 300
                    ? connection.getInputStream() : connection.getErrorStream());
            JSONObject response = new JSONObject(responseBody);
            connection.disconnect();

            if (status >= 200 && status < 300) {
                return Result.success(
                        response.optString("username", mUsername),
                        response.optString("display_name", mUsername),
                        response.optString("app_password", ""));
            }

            String message = response.optString("message", "Connexion refusée.");
            return Result.failure(message);
        } catch (IOException | JSONException e) {
            Log.e(TAG, "Erreur lors de la connexion Afrocinex", e);
            return Result.failure("Impossible de contacter le serveur.");
        }
    }

    @Override
    protected void onPostExecute(Result result) {
        if (mCallback != null) {
            mCallback.onLoginResult(result);
        }
    }

    private String readStream(java.io.InputStream stream) throws IOException {
        if (stream == null) {
            return "{}";
        }
        BufferedReader reader = new BufferedReader(new InputStreamReader(stream,
                StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            sb.append(line);
        }
        reader.close();
        return sb.toString();
    }
}
