/*
 * Copyright (c) 2016 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.example.android.tvleanback.ui;

import android.app.Activity;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.leanback.app.GuidedStepFragment;
import androidx.leanback.widget.GuidanceStylist;
import androidx.leanback.widget.GuidedAction;
import android.text.InputType;
import android.widget.Toast;

import com.example.android.tvleanback.R;
import com.example.android.tvleanback.data.AfrocinexAuthClient;
import com.example.android.tvleanback.data.AfrocinexAuthManager;

import java.util.List;

public class AuthenticationActivity extends Activity {
    private static final int CONTINUE = 2;
    private static final long ACTION_USERNAME = 1;
    private static final long ACTION_PASSWORD = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (null == savedInstanceState) {
            GuidedStepFragment.addAsRoot(this, new FirstStepFragment(), android.R.id.content);
        }
    }

    public static class FirstStepFragment extends GuidedStepFragment {

        private GuidedAction mUsernameAction;
        private GuidedAction mPasswordAction;
        private GuidedAction mLoginAction;

        @Override
        public int onProvideTheme() {
            return R.style.Theme_Example_Leanback_GuidedStep_First;
        }

        @Override
        @NonNull
        public GuidanceStylist.Guidance onCreateGuidance(@NonNull Bundle savedInstanceState) {
            String title = getString(R.string.pref_title_screen_signin);
            String description = getString(R.string.pref_title_login_description);
            Drawable icon = getActivity().getDrawable(R.drawable.ic_main_icon);
            return new GuidanceStylist.Guidance(title, description, "", icon);
        }

        @Override
        public void onCreateActions(@NonNull List<GuidedAction> actions, Bundle savedInstanceState) {
            mUsernameAction = new GuidedAction.Builder()
                    .id(ACTION_USERNAME)
                    .title(getString(R.string.pref_title_username))
                    .descriptionEditable(true)
                    .build();
            mPasswordAction = new GuidedAction.Builder()
                    .id(ACTION_PASSWORD)
                    .title(getString(R.string.pref_title_password))
                    .descriptionEditable(true)
                    .descriptionInputType(InputType.TYPE_TEXT_VARIATION_PASSWORD | InputType.TYPE_CLASS_TEXT)
                    .build();
            mLoginAction = new GuidedAction.Builder()
                    .id(CONTINUE)
                    .title(getString(R.string.guidedstep_continue))
                    .build();
            actions.add(mUsernameAction);
            actions.add(mPasswordAction);
            actions.add(mLoginAction);
        }

        @Override
        public void onGuidedActionClicked(GuidedAction action) {
            if (action.getId() != CONTINUE) {
                return;
            }

            String username = String.valueOf(mUsernameAction.getDescription());
            String password = String.valueOf(mPasswordAction.getDescription());

            if (username.trim().isEmpty() || password.isEmpty()) {
                Toast.makeText(getActivity(), getString(R.string.login_error_missing_fields),
                        Toast.LENGTH_SHORT).show();
                return;
            }

            mLoginAction.setEnabled(false);
            mLoginAction.setTitle(getString(R.string.login_in_progress));
            notifyActionChanged(findActionPositionById(CONTINUE));

            String baseApiUrl = getString(R.string.catalog_url);
            final Activity activity = getActivity();

            new AfrocinexAuthClient(baseApiUrl, username, password,
                    new AfrocinexAuthClient.Callback() {
                        @Override
                        public void onLoginResult(AfrocinexAuthClient.Result result) {
                            if (activity == null || activity.isFinishing()) {
                                return;
                            }

                            if (result.success) {
                                AfrocinexAuthManager.saveCredentials(activity, result.username,
                                        result.appPassword, result.displayName);
                                Toast.makeText(activity,
                                        getString(R.string.login_success, result.displayName),
                                        Toast.LENGTH_SHORT).show();
                                activity.finishAfterTransition();
                            } else {
                                mLoginAction.setEnabled(true);
                                mLoginAction.setTitle(getString(R.string.guidedstep_continue));
                                notifyActionChanged(findActionPositionById(CONTINUE));
                                Toast.makeText(activity, result.errorMessage, Toast.LENGTH_LONG)
                                        .show();
                            }
                        }
                    }).execute();
        }
    }
}
