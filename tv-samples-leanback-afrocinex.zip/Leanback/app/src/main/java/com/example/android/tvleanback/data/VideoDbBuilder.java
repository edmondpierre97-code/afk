/*
 * Copyright (c) 2016 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * -----------------------------------------------------------------------
 * Adapté pour Afrocinex : la source de données n'est plus un unique fichier
 * JSON de démo, mais l'API REST du plugin "Afrocinex API TV"
 * (endpoints /films et /series). Aucune URL de lecture réelle n'est
 * disponible à ce stade : elle sera récupérée plus tard via /play/{id}
 * une fois l'utilisateur connecté (étape ultérieure).
 */
package com.example.android.tvleanback.data;

import android.content.ContentValues;
import android.content.Context;
import android.media.Rating;
import androidx.annotation.NonNull;
import android.util.Log;

import com.example.android.tvleanback.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

/**
 * The VideoDbBuilder fetches films and series from the Afrocinex API
 * (métadonnées publiques uniquement) and turns them into rows ready to be
 * inserted into the local SQLite database.
 */
public class VideoDbBuilder {

    // Chemins des endpoints Afrocinex, ajoutés à l'URL de base (catalog_url).
    private static final String PATH_FILMS = "/films";
    private static final String PATH_SERIES = "/series";

    // Clés du JSON renvoyé par l'API Afrocinex.
    private static final String TAG_ITEMS = "items";
    private static final String TAG_ID = "id";
    private static final String TAG_TYPE = "type";
    private static final String TAG_TITLE = "title";
    private static final String TAG_POSTER = "poster";
    private static final String TAG_BACKGROUND = "background";
    private static final String TAG_YEAR = "year";
    private static final String TAG_DURATION = "duration";
    private static final String TAG_GENRES = "genres";
    private static final String TAG_GENRE_NAME = "name";

    // Valeurs de type utilisées par l'API.
    private static final String TYPE_FILM = "film";
    private static final String TYPE_SERIE = "serie";

    private static final String TAG = "VideoDbBuilder";

    private Context mContext;

    /**
     * Default constructor that can be used for tests
     */
    public VideoDbBuilder() {

    }

    public VideoDbBuilder(Context mContext) {
        this.mContext = mContext;
    }

    /**
     * Récupère les films puis les séries depuis l'API Afrocinex et renvoie
     * l'ensemble des lignes prêtes à être insérées en base.
     *
     * @param baseApiUrl L'URL de base de l'API, ex. https://afrocinex.com/wp-json/afrocinex-api-tv/v1
     */
    public @NonNull List<ContentValues> fetch(String baseApiUrl)
            throws IOException, JSONException {

        List<ContentValues> videosToInsert = new ArrayList<>();

        JSONObject filmsData = fetchJSON(baseApiUrl + PATH_FILMS);
        videosToInsert.addAll(buildMedia(filmsData));

        JSONObject seriesData = fetchJSON(baseApiUrl + PATH_SERIES);
        videosToInsert.addAll(buildMedia(seriesData));

        return videosToInsert;
    }

    /**
     * Transforme le contenu JSON d'une réponse Afrocinex ("items": [...])
     * en une liste de ContentValues.
     *
     * @param jsonObj La réponse JSON de /films ou /series
     * @throws JSONException si le JSON est invalide
     */
    public List<ContentValues> buildMedia(JSONObject jsonObj) throws JSONException {

        List<ContentValues> videosToInsert = new ArrayList<>();
        JSONArray items = jsonObj.optJSONArray(TAG_ITEMS);
        if (items == null) {
            return videosToInsert;
        }

        for (int i = 0; i < items.length(); i++) {
            JSONObject item = items.getJSONObject(i);

            String contentId = item.optString(TAG_ID);
            String itemType = item.optString(TAG_TYPE);
            String title = item.optString(TAG_TITLE);
            String cardImageUrl = item.optString(TAG_POSTER);
            String bgImageUrl = item.optString(TAG_BACKGROUND);
            if (bgImageUrl == null || bgImageUrl.isEmpty()) {
                // Les séries n'ont pas toujours d'image de fond distincte : on retombe sur l'affiche.
                bgImageUrl = cardImageUrl;
            }
            String year = item.optString(TAG_YEAR);
            String duration = item.optString(TAG_DURATION);

            // Le nom du premier genre sert de catégorie d'affichage (regroupement par rangée).
            String categoryName = TYPE_SERIE.equals(itemType) ? "Séries" : "Films";
            JSONArray genres = item.optJSONArray(TAG_GENRES);
            if (genres != null && genres.length() > 0) {
                JSONObject firstGenre = genres.getJSONObject(0);
                String genreName = firstGenre.optString(TAG_GENRE_NAME);
                if (genreName != null && !genreName.isEmpty()) {
                    categoryName = genreName;
                }
            }

            String studioLabel = TYPE_SERIE.equals(itemType) ? "Série" : "Film";

            // Aucune URL de lecture réelle à ce stade (nécessite une connexion utilisateur
            // et l'appel à /play/{id}, prévu dans une étape ultérieure). On utilise une
            // référence interne unique afrocinex://{type}/{id} pour respecter la contrainte
            // d'unicité de la colonne, en attendant le branchement du lecteur.
            String placeholderVideoUrl = "afrocinex://" + itemType + "/" + contentId;

            ContentValues videoValues = new ContentValues();
            videoValues.put(VideoContract.VideoEntry.COLUMN_CATEGORY, categoryName);
            videoValues.put(VideoContract.VideoEntry.COLUMN_NAME, title);
            videoValues.put(VideoContract.VideoEntry.COLUMN_DESC, "");
            videoValues.put(VideoContract.VideoEntry.COLUMN_VIDEO_URL, placeholderVideoUrl);
            videoValues.put(VideoContract.VideoEntry.COLUMN_CARD_IMG, cardImageUrl);
            videoValues.put(VideoContract.VideoEntry.COLUMN_BG_IMAGE_URL, bgImageUrl);
            videoValues.put(VideoContract.VideoEntry.COLUMN_STUDIO, studioLabel);
            videoValues.put(VideoContract.VideoEntry.COLUMN_CONTENT_ID, contentId);
            videoValues.put(VideoContract.VideoEntry.COLUMN_ITEM_TYPE, itemType);

            // Valeurs fixes par défaut (à affiner lors du branchement du lecteur réel).
            videoValues.put(VideoContract.VideoEntry.COLUMN_CONTENT_TYPE, "video/mp4");
            videoValues.put(VideoContract.VideoEntry.COLUMN_IS_LIVE, false);
            videoValues.put(VideoContract.VideoEntry.COLUMN_AUDIO_CHANNEL_CONFIG, "2.0");
            videoValues.put(VideoContract.VideoEntry.COLUMN_PRODUCTION_YEAR, year);
            videoValues.put(VideoContract.VideoEntry.COLUMN_DURATION, duration);
            videoValues.put(VideoContract.VideoEntry.COLUMN_RATING_STYLE,
                    Rating.RATING_5_STARS);
            videoValues.put(VideoContract.VideoEntry.COLUMN_RATING_SCORE, 0f);
            if (mContext != null) {
                videoValues.put(VideoContract.VideoEntry.COLUMN_PURCHASE_PRICE,
                        mContext.getResources().getString(R.string.buy_2));
                videoValues.put(VideoContract.VideoEntry.COLUMN_RENTAL_PRICE,
                        mContext.getResources().getString(R.string.rent_2));
                videoValues.put(VideoContract.VideoEntry.COLUMN_ACTION,
                        mContext.getResources().getString(R.string.global_search));
            }

            // TODO: Dimensions réelles à récupérer si besoin plus tard.
            videoValues.put(VideoContract.VideoEntry.COLUMN_VIDEO_WIDTH, 1280);
            videoValues.put(VideoContract.VideoEntry.COLUMN_VIDEO_HEIGHT, 720);

            videosToInsert.add(videoValues);
        }
        return videosToInsert;
    }

    /**
     * Fetch JSON object from a given URL.
     *
     * @return the JSONObject representation of the response
     * @throws JSONException
     * @throws IOException
     */
    private JSONObject fetchJSON(String urlString) throws JSONException, IOException {
        BufferedReader reader = null;
        java.net.URL url = new java.net.URL(urlString);
        HttpsURLConnection urlConnection = (HttpsURLConnection) url.openConnection();
        try {
            reader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream(),
                    "utf-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
            String json = sb.toString();
            return new JSONObject(json);
        } finally {
            urlConnection.disconnect();
            if (null != reader) {
                try {
                    reader.close();
                } catch (IOException e) {
                    Log.e(TAG, "JSON feed closed", e);
                }
            }
        }
    }
}
