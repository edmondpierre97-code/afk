/*
 * Afrocinex — Récupère la liste des saisons et épisodes d'une série auprès de
 * l'API Afrocinex (/series/{id}/episodes), pour affichage sur l'écran de détail
 * d'une série (une rangée par saison).
 */
package com.example.android.tvleanback.data;

import android.os.AsyncTask;
import android.util.Log;

import com.example.android.tvleanback.model.Video;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

public class AfrocinexSeasonsFetcher extends AsyncTask<Void, Void, List<AfrocinexSeasonsFetcher.Season>> {

    private static final String TAG = "AfrocinexSeasonsFetcher";

    /**
     * Une saison : un nom d'affichage et la liste de ses épisodes (déjà sous forme de Video,
     * réutilisable directement par CardPresenter/VideoDetailsActivity).
     */
    public static class Season {
        public final String name;
        public final List<Video> episodes;

        public Season(String name, List<Video> episodes) {
            this.name = name;
            this.episodes = episodes;
        }
    }

    public interface Callback {
        void onSeasonsReady(List<Season> seasons);
    }

    private final String mBaseApiUrl;
    private final String mSeriesId;
    private final String mSeriesCategory;
    private final Callback mCallback;

    public AfrocinexSeasonsFetcher(String baseApiUrl, String seriesId, String seriesCategory,
            Callback callback) {
        mBaseApiUrl = baseApiUrl;
        mSeriesId = seriesId;
        mSeriesCategory = seriesCategory;
        mCallback = callback;
    }

    @Override
    protected List<Season> doInBackground(Void... voids) {
        if (mSeriesId == null || mSeriesId.isEmpty()) {
            return new ArrayList<>();
        }

        String url = mBaseApiUrl + "/series/" + mSeriesId + "/episodes";
        List<Season> seasons = new ArrayList<>();

        try {
            JSONObject response = fetchJSON(url);
            JSONArray seasonsArray = response.optJSONArray("seasons");
            if (seasonsArray == null) {
                return seasons;
            }

            for (int i = 0; i < seasonsArray.length(); i++) {
                JSONObject seasonObj = seasonsArray.getJSONObject(i);
                String seasonName = seasonObj.optString("name", "");
                if (seasonName.isEmpty()) {
                    seasonName = "Saison " + seasonObj.optInt("index", i + 1);
                }

                List<Video> episodes = new ArrayList<>();
                JSONArray episodesArray = seasonObj.optJSONArray("episodes");
                if (episodesArray != null) {
                    for (int j = 0; j < episodesArray.length(); j++) {
                        JSONObject episodeObj = episodesArray.getJSONObject(j);
                        episodes.add(buildEpisodeVideo(episodeObj));
                    }
                }

                seasons.add(new Season(seasonName, episodes));
            }
        } catch (IOException | JSONException e) {
            Log.e(TAG, "Erreur lors de la récupération des saisons/épisodes Afrocinex", e);
        }

        return seasons;
    }

    private Video buildEpisodeVideo(JSONObject episodeObj) {
        String episodeId = episodeObj.optString("id");
        String title = episodeObj.optString("title", "");
        int episodeNumber = episodeObj.optInt("episode_number", 0);
        String poster = episodeObj.optString("poster", "");

        String displayTitle = episodeNumber > 0 ? (episodeNumber + ". " + title) : title;

        long localId;
        try {
            localId = Long.parseLong(episodeId);
        } catch (NumberFormatException e) {
            localId = 0L;
        }

        return new Video.VideoBuilder()
                .id(localId)
                .category(mSeriesCategory)
                .title(displayTitle)
                .description("") // Complétée à l'ouverture de la fiche via /episodes/{id}.
                .videoUrl("afrocinex://episode/" + episodeId)
                .bgImageUrl(poster)
                .cardImageUrl(poster)
                .studio("Épisode")
                .contentId(episodeId)
                .itemType("episode")
                .build();
    }

    @Override
    protected void onPostExecute(List<Season> seasons) {
        if (mCallback != null) {
            mCallback.onSeasonsReady(seasons);
        }
    }

    private JSONObject fetchJSON(String urlString) throws IOException, JSONException {
        BufferedReader reader = null;
        URL url = new URL(urlString);
        HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
        try {
            reader = new BufferedReader(new InputStreamReader(connection.getInputStream(),
                    "utf-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
            return new JSONObject(sb.toString());
        } finally {
            connection.disconnect();
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    Log.e(TAG, "Fermeture du flux échouée", e);
                }
            }
        }
    }
}
