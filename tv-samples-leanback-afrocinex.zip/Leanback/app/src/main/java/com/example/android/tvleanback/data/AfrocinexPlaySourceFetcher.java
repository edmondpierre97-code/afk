/*
 * Afrocinex — Appelle GET /play/{id} sur l'API Afrocinex (authentifié, en-tête
 * Basic Auth fourni par AfrocinexAuthManager) pour obtenir la ou les source(s)
 * vidéo réelles d'un film ou d'un épisode, juste avant de lancer la lecture.
 *
 * Aujourd'hui le serveur renvoie une URL "brute" (non encore sécurisée par un
 * jeton Infomaniak, en attente de leur réponse). Le jour où la sécurisation
 * sera en place, seul le plugin WordPress changera — ce fichier n'aura rien à
 * changer, puisqu'il se contente d'utiliser l'URL que le serveur lui donne.
 */
package com.example.android.tvleanback.data;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class AfrocinexPlaySourceFetcher
        extends AsyncTask<Void, Void, AfrocinexPlaySourceFetcher.Result> {

    private static final String TAG = "AfrocinexPlaySource";
    private static final String TYPE_EPISODE = "episode";

    /** Résultat renvoyé par l'appel API : soit une URL de lecture, soit une erreur lisible. */
    public static class Result {
        public final boolean success;
        public final String playUrl;
        public final String errorMessage;
        /** true si l'erreur vient d'une absence/expiration de connexion (401). */
        public final boolean authRequired;

        private Result(boolean success, String playUrl, String errorMessage,
                boolean authRequired) {
            this.success = success;
            this.playUrl = playUrl;
            this.errorMessage = errorMessage;
            this.authRequired = authRequired;
        }

        static Result success(String playUrl) {
            return new Result(true, playUrl, "", false);
        }

        static Result failure(String errorMessage, boolean authRequired) {
            return new Result(false, "", errorMessage, authRequired);
        }
    }

    public interface Callback {
        void onPlaySourceReady(Result result);
    }

    private final Context mAppContext;
    private final String mBaseApiUrl;
    private final String mContentId;
    private final String mItemType;
    private final Callback mCallback;

    public AfrocinexPlaySourceFetcher(Context context, String baseApiUrl, String contentId,
            String itemType, Callback callback) {
        mAppContext = context.getApplicationContext();
        mBaseApiUrl = baseApiUrl;
        mContentId = contentId;
        mItemType = itemType;
        mCallback = callback;
    }

    @Override
    protected Result doInBackground(Void... voids) {
        if (mContentId == null || mContentId.isEmpty()) {
            return Result.failure("Contenu Afrocinex inconnu.", false);
        }

        String type = TYPE_EPISODE.equals(mItemType) ? "episode" : "film";
        String url = mBaseApiUrl + "/play/" + mContentId + "?type=" + type;

        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(url).openConnection();
            connection.setRequestMethod("GET");

            String authHeader = AfrocinexAuthManager.getAuthorizationHeader(mAppContext);
            if (authHeader == null) {
                return Result.failure("Connexion requise pour lire ce contenu.", true);
            }
            connection.setRequestProperty("Authorization", authHeader);

            int status = connection.getResponseCode();
            String body = readStream(status >= 200 && status < 300
                    ? connection.getInputStream() : connection.getErrorStream());

            if (status == 401) {
                return Result.failure("Session expirée, merci de te reconnecter.", true);
            }
            if (status == 403) {
                JSONObject error = safeJson(body);
                String message = error != null
                        ? error.optString("message", "Abonnement requis pour ce contenu.")
                        : "Abonnement requis pour ce contenu.";
                return Result.failure(message, false);
            }
            if (status != 200) {
                JSONObject error = safeJson(body);
                String message = error != null
                        ? error.optString("message", "Ce contenu n'est pas disponible.")
                        : "Ce contenu n'est pas disponible.";
                return Result.failure(message, false);
            }

            JSONObject response = new JSONObject(body);
            JSONArray sources = response.optJSONArray("sources");
            String playUrl = pickBestSource(sources);

            if (playUrl == null || playUrl.isEmpty()) {
                return Result.failure("Aucune source vidéo disponible pour ce contenu.", false);
            }

            return Result.success(playUrl);
        } catch (IOException | JSONException e) {
            Log.e(TAG, "Erreur lors de la récupération de la source de lecture", e);
            return Result.failure("Impossible de contacter le serveur.", false);
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    /** Choisit la source marquée "main", sinon la première disponible. */
    private String pickBestSource(JSONArray sources) {
        if (sources == null || sources.length() == 0) {
            return null;
        }
        String firstUrl = null;
        for (int i = 0; i < sources.length(); i++) {
            JSONObject row = sources.optJSONObject(i);
            if (row == null) {
                continue;
            }
            String rowUrl = row.optString("url", null);
            if (rowUrl == null || rowUrl.isEmpty()) {
                continue;
            }
            if (firstUrl == null) {
                firstUrl = rowUrl;
            }
            if (row.optBoolean("main", false)) {
                return rowUrl;
            }
        }
        return firstUrl;
    }

    private JSONObject safeJson(String body) {
        try {
            return new JSONObject(body);
        } catch (JSONException e) {
            return null;
        }
    }

    @Override
    protected void onPostExecute(Result result) {
        if (mCallback != null) {
            mCallback.onPlaySourceReady(result);
        }
    }

    private String readStream(InputStream stream) throws IOException {
        if (stream == null) {
            return "{}";
        }
        BufferedReader reader = new BufferedReader(
                new InputStreamReader(stream, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            sb.append(line);
        }
        reader.close();
        return sb.toString();
    }
}
