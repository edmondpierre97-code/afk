/*
 * Afrocinex — Stocke localement les identifiants obtenus après connexion (nom
 * d'utilisateur + mot de passe d'application WordPress) et fournit l'en-tête
 * d'authentification à utiliser sur les appels protégés (/play).
 */
package com.example.android.tvleanback.data;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

public class AfrocinexAuthManager {

    private static final String PREFS_NAME = "afrocinex_auth";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_APP_PASSWORD = "app_password";
    private static final String KEY_DISPLAY_NAME = "display_name";

    private AfrocinexAuthManager() {
        // Classe utilitaire statique, pas d'instanciation.
    }

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext()
                .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    /**
     * Enregistre les identifiants reçus de /auth/login.
     */
    public static void saveCredentials(Context context, String username, String appPassword,
            String displayName) {
        prefs(context).edit()
                .putString(KEY_USERNAME, username)
                .putString(KEY_APP_PASSWORD, appPassword)
                .putString(KEY_DISPLAY_NAME, displayName)
                .apply();
    }

    public static void clearCredentials(Context context) {
        prefs(context).edit().clear().apply();
    }

    public static boolean isLoggedIn(Context context) {
        return !getUsername(context).isEmpty() && !getAppPassword(context).isEmpty();
    }

    public static String getUsername(Context context) {
        return prefs(context).getString(KEY_USERNAME, "");
    }

    public static String getAppPassword(Context context) {
        return prefs(context).getString(KEY_APP_PASSWORD, "");
    }

    public static String getDisplayName(Context context) {
        return prefs(context).getString(KEY_DISPLAY_NAME, "");
    }

    /**
     * Construit la valeur de l'en-tête HTTP "Authorization" (Basic Auth) à envoyer
     * sur les appels protégés, à partir des identifiants stockés. Renvoie null si
     * l'utilisateur n'est pas connecté.
     */
    public static String getAuthorizationHeader(Context context) {
        if (!isLoggedIn(context)) {
            return null;
        }
        String credentials = getUsername(context) + ":" + getAppPassword(context);
        String encoded = Base64.encodeToString(credentials.getBytes(), Base64.NO_WRAP);
        return "Basic " + encoded;
    }
}
