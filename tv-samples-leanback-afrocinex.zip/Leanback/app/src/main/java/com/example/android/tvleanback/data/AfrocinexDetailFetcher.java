/*
 * Afrocinex — Récupère le détail complet (description, casting) d'un film ou
 * d'une série auprès de l'API Afrocinex (/films/{id} ou /series/{id}),
 * pour compléter les données déjà présentes en base locale (titre, affiche...).
 *
 * Se lance en tâche de fond (AsyncTask) depuis VideoDetailsFragment : la fiche
 * s'affiche immédiatement avec les données locales, puis se met à jour dès que
 * la réponse de l'API arrive.
 */
package com.example.android.tvleanback.data;

import android.os.AsyncTask;
import android.text.Html;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

public class AfrocinexDetailFetcher extends AsyncTask<Void, Void, AfrocinexDetailFetcher.Result> {

    private static final String TAG = "AfrocinexDetailFetcher";

    private static final String TYPE_SERIE = "serie";
    private static final String TYPE_EPISODE = "episode";

    /**
     * Résultat renvoyé par l'appel API, prêt à être affiché.
     */
    public static class Result {
        public final String description;
        public final String castLine;

        public Result(String description, String castLine) {
            this.description = description;
            this.castLine = castLine;
        }
    }

    public interface Callback {
        void onDetailReady(Result result);
    }

    private final String mBaseApiUrl;
    private final String mContentId;
    private final String mItemType;
    private final Callback mCallback;

    public AfrocinexDetailFetcher(String baseApiUrl, String contentId, String itemType,
            Callback callback) {
        mBaseApiUrl = baseApiUrl;
        mContentId = contentId;
        mItemType = itemType;
        mCallback = callback;
    }

    @Override
    protected Result doInBackground(Void... voids) {
        if (mContentId == null || mContentId.isEmpty()) {
            return null;
        }

        String path = TYPE_SERIE.equals(mItemType) ? "/series/"
                : TYPE_EPISODE.equals(mItemType) ? "/episodes/"
                : "/films/";
        String url = mBaseApiUrl + path + mContentId;

        try {
            JSONObject detail = fetchJSON(url);

            String description = detail.optString("description", "");
            // Le champ vient de get_the_content() côté WordPress : peut contenir du HTML.
            description = Html.fromHtml(description, Html.FROM_HTML_MODE_LEGACY)
                    .toString().trim();

            String castLine = buildCastLine(detail.optJSONArray("cast"));

            return new Result(description, castLine);
        } catch (IOException | JSONException e) {
            Log.e(TAG, "Erreur lors de la récupération du détail Afrocinex", e);
            return null;
        }
    }

    @Override
    protected void onPostExecute(Result result) {
        if (result != null && mCallback != null) {
            mCallback.onDetailReady(result);
        }
    }

    private String buildCastLine(JSONArray cast) {
        if (cast == null || cast.length() == 0) {
            return "";
        }
        StringBuilder sb = new StringBuilder("Avec : ");
        for (int i = 0; i < cast.length(); i++) {
            JSONObject person = cast.optJSONObject(i);
            if (person == null) {
                continue;
            }
            String name = person.optString("name", "");
            if (name.isEmpty()) {
                continue;
            }
            if (sb.length() > "Avec : ".length()) {
                sb.append(", ");
            }
            sb.append(name);
        }
        return sb.length() > "Avec : ".length() ? sb.toString() : "";
    }

    private JSONObject fetchJSON(String urlString) throws IOException, JSONException {
        BufferedReader reader = null;
        URL url = new URL(urlString);
        HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
        try {
            reader = new BufferedReader(new InputStreamReader(connection.getInputStream(),
                    "utf-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
            return new JSONObject(sb.toString());
        } finally {
            connection.disconnect();
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    Log.e(TAG, "Fermeture du flux échouée", e);
                }
            }
        }
    }
}
